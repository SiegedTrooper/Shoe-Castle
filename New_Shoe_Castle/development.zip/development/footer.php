<!--<link rel="stylesheet" href="css/footer.css">-->
<br>
<br>

<div style="background-color:#333;">
  <div class="container-fluid">
  	  <div class="container">
          <br>
<div class="footer-content" style="display: flex;width: 100%;justify-content: space-between;">

    <img src="./images/light-logo.png" style="max-height:75px" class="logo" alt="Shoe Castle logo">
</div><div style="color:rgba(255, 255, 255, 0.75);">
          <br>

    <p class="footer-title">About Company</p>
    <p class="info" style="color:rgba(255, 255, 255, 0.75);text-transform: capitalize;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat tempore ad suscipit, eos eius quisquam sed optio nisi quaerat fugiat ratione et vero maxime praesentium, architecto minima reiciendis iste quo deserunt assumenda alias ducimus. Ullam odit maxime id voluptates rerum tenetur corporis laboriosam! Cum error ipsum laborum tempore in rerum necessitatibus nostrum nobis modi! Debitis adipisci illum nemo aperiam sed, et accusamus ut officiis. Laborum illo exercitationem quo culpa reprehenderit excepturi distinctio tempore cupiditate praesentium nisi ut iusto, assumenda perferendis facilis voluptas autem fuga sunt ab debitis voluptatum harum eum. Asperiores, natus! Est deserunt incidunt quasi placeat omnis, itaque harum?</p>      
    <p class="info">Support Emails - 
    <a href="mailto:help@shoecastle.org">help@shoecastle.org</a>, 
    <a href="mailto:customersupport@shoecastle.org">customersupport@shoecastle.org</a></p>
    <p>Telephone - 
    <a href="tel:2104567890">(210) 456-7890</a>, 
    <a href="tel:6301324895">(630) 132-4895</a></p>
    <div class="footer-social-container" style="color: #fff;margin-left: 20px;text-transform: capitalize;">
        <div style="text-align: center;text-decoration: underline;">
            <a style="color: #fff;margin-left: 20px;text-transform: capitalize;" href="#" class="social-link">terms &amp services</a>
            <a style="color: #fff;margin-left: 20px;text-transform: capitalize;" href="#" class="social-link">privacy page</a>
            <a style="color: #fff;margin-left: 20px;text-transform: capitalize;" href="#" class="social-link">instagram</a>
            <a style="color: #fff;margin-left: 20px;text-transform: capitalize;" href="#" class="social-link">facebook</a>
            <a style="color: #fff;margin-left: 20px;text-transform: capitalize;" href="#" class="social-link">twitter</a>
        </div>
    </div>
</div>
</div>
</div>
</div>
<div style="background-color:#333;">
<p class="footer-credit" style="width:100%;text-align:center;color: #fff;background: rgba(0, 0, 0, 0.2);">Shoe Castle, Best drip on Earth</p>
    <div>