<!DOCTYPE html>
<?php
echo ';<iframe style="max-width:18rem;max-height:18rem;display: block;margin-left: auto;margin-right: auto;" src="https://giphy.com/embed/gflzte2SEjFWHIDZij" width="480" height="480" frameBorder="0"></iframe>';
echo '<p>TEST</p>';